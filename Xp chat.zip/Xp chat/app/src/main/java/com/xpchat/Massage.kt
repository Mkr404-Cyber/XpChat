package com.xpchat

data class Message(
    var message: String? = null,
    var senderId: String? = null
)