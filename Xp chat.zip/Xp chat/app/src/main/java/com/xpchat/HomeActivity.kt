package com.xpchat

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ChatListAdapter
    private val chatList = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        recyclerView = findViewById(R.id.recyclerViewChats)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = ChatListAdapter(chatList) { userId ->
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("chatUserId", userId)
            startActivity(intent)
        }
        recyclerView.adapter = adapter

        loadChatList()
    }

    private fun loadChatList() {
        val currentUser = FirebaseAuth.getInstance().currentUser ?: return
        val db = FirebaseFirestore.getInstance()

        db.collection("users")
            .get()
            .addOnSuccessListener { documents ->
                chatList.clear()
                for (doc in documents) {
                    val userId = doc.id
                    if (userId != currentUser.uid) {
                        chatList.add(userId)
                    }
                }
                adapter.notifyDataSetChanged()
            }
    }
}